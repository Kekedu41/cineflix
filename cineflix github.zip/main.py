from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
import urllib.request
import urllib.parse
import json

app = FastAPI(title="Cinéflix - Ultimate Streaming Pro", version="6.0")

TMDB_API_KEY = "264fac9bf2abf8c206d1dac490046efc"

def fetch_tmdb(url):
    """Fonction utilitaire pour interroger l'API TMDB"""
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        print(f"Erreur API TMDB ({url}): {e}")
        return {}

def render_grid(items, item_type="movie"):
    """Génère une grille de cartes (Films ou Séries)"""
    html = ""
    for item in items:
        title = item.get("title") or item.get("name", "Titre indisponible")
        poster_path = item.get("poster_path")
        item_id = item.get("id")
        
        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}"
            link = f"/watch?id={item_id}&type={item_type}"
            html += f"""
            <a href="{link}" class="movie-card">
                <img src="{poster_url}" alt="{title}" loading="lazy">
                <div class="movie-title">{title}</div>
            </a>
            """
    return html if html else "<p style='color: #777;'>Aucun contenu disponible.</p>"

def base_layout(active_tab, content, search_query=""):
    """Layout global ultra design style Netflix/Movix"""
    return f"""
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cinéflix - Streaming</title>
        <style>
            :root {{
                --bg-color: #0b0b0e;
                --card-bg: #16161a;
                --primary: #e50914;
                --primary-hover: #b20710;
                --text-main: #ffffff;
                --text-muted: #94a3b8;
            }}
            body {{ background-color: var(--bg-color); color: var(--text-main); font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; margin: 0; padding: 0; overflow-x: hidden; }}
            
            header {{ background: rgba(11, 11, 14, 0.9); backdrop-filter: blur(10px); padding: 15px 40px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.08); position: sticky; top: 0; z-index: 1000; flex-wrap: wrap; gap: 20px; }}
            .nav-left {{ display: flex; align-items: center; gap: 40px; }}
            .logo {{ color: var(--primary); font-size: 1.8rem; font-weight: 800; text-decoration: none; letter-spacing: 1px; }}
            .nav-links {{ display: flex; gap: 20px; }}
            .nav-links a {{ color: var(--text-muted); text-decoration: none; font-weight: 600; font-size: 0.95rem; transition: color 0.2s; }}
            .nav-links a:hover, .nav-links a.active {{ color: var(--text-main); }}
            
            .search-form {{ display: flex; gap: 10px; }}
            .search-input {{ padding: 10px 16px; width: 240px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 8px; font-size: 0.9rem; outline: none; transition: border-color 0.2s; }}
            .search-input:focus {{ border-color: var(--primary); }}
            .search-btn {{ padding: 10px 20px; background: var(--primary); color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; transition: background 0.2s; }}
            .search-btn:hover {{ background: var(--primary-hover); }}
            
            .container {{ max-width: 1400px; margin: 40px auto; padding: 0 20px; }}
            h2 {{ margin-bottom: 25px; font-weight: 600; color: #f1f5f9; font-size: 1.4rem; border-left: 4px solid var(--primary); padding-left: 12px; }}
            
            .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 25px; margin-bottom: 50px; }}
            .movie-card {{ background: var(--card-bg); border-radius: 12px; overflow: hidden; text-decoration: none; color: white; transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.3s; box-shadow: 0 4px 12px rgba(0,0,0,0.3); display: flex; flex-direction: column; border: 1px solid rgba(255,255,255,0.04); }}
            .movie-card:hover {{ transform: translateY(-8px); box-shadow: 0 12px 25px rgba(229, 9, 20, 0.25); border-color: rgba(229, 9, 20, 0.3); z-index: 10; }}
            .movie-card img {{ width: 100%; height: 300px; object-fit: cover; }}
            .movie-title {{ padding: 15px; font-size: 0.95rem; font-weight: 600; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }}
            
            /* Tiroirs / Accordéons */
            .drawer {{ background: var(--card-bg); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; margin-bottom: 20px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.4); transition: border-color 0.2s; }}
            .drawer:hover {{ border-color: rgba(229, 9, 20, 0.4); }}
            .drawer-summary {{ display: flex; align-items: center; gap: 20px; padding: 15px 25px; cursor: pointer; list-style: none; background: linear-gradient(to right, #1a1a22, #121216); }}
            .drawer-summary::-webkit-details-marker {{ display: none; }}
            .drawer-poster {{ width: 70px; height: 100px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.6); }}
            .drawer-info h3 {{ margin: 0 0 5px 0; font-size: 1.3rem; color: #fff; }}
            .drawer-info p {{ margin: 0; color: var(--text-muted); font-size: 0.9rem; }}
            .drawer-content {{ padding: 25px; background: var(--bg-color); border-top: 1px solid rgba(255,255,255,0.06); }}
        </style>
    </head>
    <body>
        <header>
            <div class="nav-left">
                <a href="/" class="logo">CINEFLIX 🎬</a>
                <div class="nav-links">
                    <a href="/" class="{'active' if active_tab == 'home' else ''}">Accueil</a>
                    <a href="/movies" class="{'active' if active_tab == 'movies' else ''}">Films</a>
                    <a href="/series" class="{'active' if active_tab == 'series' else ''}">Séries</a>
                    <a href="/sagas" class="{'active' if active_tab == 'sagas' else ''}">Sagas</a>
                </div>
            </div>
            <form action="/" method="get" class="search-form">
                <input type="text" name="q" class="search-input" placeholder="Rechercher un film, série..." value="{search_query}">
                <button type="submit" class="search-btn">Rechercher</button>
            </form>
        </header>

        <div class="container">
            {content}
        </div>
    </body>
    </html>
    """

@app.get("/", response_class=HTMLResponse)
def home(q: str = None):
    if q:
        encoded_q = urllib.parse.quote(q)
        movie_data = fetch_tmdb(f"https://api.themoviedb.org/3/search/movie?api_key={TMDB_API_KEY}&language=fr-FR&query={encoded_q}")
        tv_data = fetch_tmdb(f"https://api.themoviedb.org/3/search/tv?api_key={TMDB_API_KEY}&language=fr-FR&query={encoded_q}")
        
        content = f"""
        <h2>🔍 Résultats de recherche pour : "{q}"</h2>
        <h3>Films</h3>
        <div class="grid">{render_grid(movie_data.get('results', []), 'movie')}</div>
        <h3 style="margin-top:40px;">Séries</h3>
        <div class="grid">{render_grid(tv_data.get('results', []), 'tv')}</div>
        """
    else:
        # Récupération des tendances pour alimenter le carrousel hero
        trending_movies = fetch_tmdb(f"https://api.themoviedb.org/3/trending/movie/day?api_key={TMDB_API_KEY}&language=fr-FR").get('results', [])
        trending_tv = fetch_tmdb(f"https://api.themoviedb.org/3/trending/tv/day?api_key={TMDB_API_KEY}&language=fr-FR").get('results', [])
        
        # Construction du Carrousel Hero (Top 5 films tendances)
        hero_slides = ""
        hero_dots = ""
        top_carousel_items = trending_movies[:5]
        
        for idx, movie in enumerate(top_carousel_items):
            m_id = movie.get("id")
            title = movie.get("title", "Titre")
            overview = movie.get("overview", "Aucun synopsis disponible.")
            backdrop = movie.get("backdrop_path")
            backdrop_url = f"https://image.tmdb.org/t/p/original{backdrop}" if backdrop else ""
            vote = round(movie.get("vote_average", 0), 1)
            year = movie.get("release_date", "2026")[:4]
            
            active_class = "active" if idx == 0 else ""
            
            hero_slides += f"""
            <div class="hero-slide {active_class}" style="background-image: url('{backdrop_url}');">
                <div class="hero-gradient"></div>
                <div class="hero-content">
                    <div class="hero-badges">
                        <span class="badge film">FILM</span>
                        <span class="badge year">📅 {year}</span>
                        <span class="badge rating">⭐ {vote} / 10</span>
                    </div>
                    <h1>{title}</h1>
                    <p>{overview}</p>
                    <div class="hero-actions">
                        <a href="/watch?id={m_id}&type=movie" class="btn-play">▶ Regarder</a>
                        <a href="/movie?id={m_id}" class="btn-info">ℹ Plus d'infos</a>
                    </div>
                </div>
            </div>
            """
            hero_dots += f"""<span class="dot {active_class}" onclick="currentSlide({idx + 1})"></span>"""

        carousel_html = f"""
        <style>
            .hero-carousel {{ position: relative; width: 100%; height: 500px; border-radius: 16px; overflow: hidden; margin-bottom: 40px; box-shadow: 0 15px 35px rgba(0,0,0,0.7); background: #111; }}
            .hero-slide {{ position: absolute; inset: 0; background-size: cover; background-position: center; opacity: 0; transition: opacity 0.8s ease-in-out; display: flex; align-items: flex-end; }}
            .hero-slide.active {{ opacity: 1; z-index: 2; }}
            .hero-gradient {{ position: absolute; inset: 0; background: linear-gradient(to top, #0b0b0e 5%, rgba(11,11,14,0.7) 50%, rgba(11,11,14,0.2) 100%); }}
            .hero-content {{ position: relative; z-index: 3; padding: 40px; max-width: 700px; }}
            .hero-badges {{ display: flex; gap: 12px; margin-bottom: 12px; font-size: 0.85rem; font-weight: bold; }}
            .badge {{ padding: 4px 10px; border-radius: 4px; }}
            .badge.film {{ background: #e50914; color: white; }}
            .badge.year, .badge.rating {{ background: rgba(255,255,255,0.2); backdrop-filter: blur(5px); color: white; }}
            .hero-content h1 {{ font-size: 3rem; margin: 0 0 12px 0; font-weight: 800; text-shadow: 2px 2px 8px rgba(0,0,0,0.8); }}
            .hero-content p {{ font-size: 1rem; color: #cbd5e1; line-height: 1.5; margin-bottom: 25px; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; text-shadow: 1px 1px 4px rgba(0,0,0,0.8); }}
            .hero-actions {{ display: flex; gap: 15px; }}
            .btn-play {{ padding: 12px 28px; background: #e50914; color: white; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 1rem; transition: background 0.2s, transform 0.2s; box-shadow: 0 4px 15px rgba(229,9,20,0.4); }}
            .btn-play:hover {{ background: #b20710; transform: scale(1.05); }}
            .btn-info {{ padding: 12px 25px; background: rgba(255,255,255,0.15); backdrop-filter: blur(5px); color: white; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 1rem; transition: background 0.2s; }}
            .btn-info:hover {{ background: rgba(255,255,255,0.25); }}
            
            .hero-dots {{ position: absolute; bottom: 20px; right: 30px; z-index: 10; display: flex; gap: 8px; align-items: center; background: rgba(0,0,0,0.5); padding: 8px 12px; border-radius: 20px; backdrop-filter: blur(5px); }}
            .dot {{ width: 10px; height: 10px; border-radius: 50%; background: rgba(255,255,255,0.4); cursor: pointer; transition: background 0.3s, transform 0.3s; }}
            .dot.active {{ background: #e50914; transform: scale(1.2); }}
        </style>

        <div class="hero-carousel" id="heroCarousel">
            {hero_slides}
            <div class="hero-dots">
                {hero_dots}
            </div>
        </div>

        <script>
            let slideIndex = 0;
            const slides = document.getElementsByClassName("hero-slide");
            const dots = document.getElementsByClassName("dot");

            function showSlides() {{
                for (let i = 0; i < slides.length; i++) {{
                    slides[i].classList.remove("active");
                    dots[i].classList.remove("active");
                }}
                slideIndex++;
                if (slideIndex > slides.length) {{ slideIndex = 1; }}
                slides[slideIndex - 1].classList.add("active");
                dots[slideIndex - 1].classList.add("active");
                setTimeout(showSlides, 6000); // Change de slide toutes les 6 secondes
            }}

            function currentSlide(n) {{
                slideIndex = n - 1;
                for (let i = 0; i < slides.length; i++) {{
                    slides[i].classList.remove("active");
                    dots[i].classList.remove("active");
                }}
                slides[slideIndex].classList.add("active");
                dots[slideIndex].classList.add("active");
            }}

            if (slides.length > 0) {{
                setTimeout(showSlides, 6000);
            }}
        </script>
        """

        content = f"""
        {carousel_html}
        <h2>🔥 Films Tendances</h2>
        <div class="grid">{render_grid(trending_movies, 'movie')}</div>
        
        <h2 style="margin-top: 50px;">📺 Séries Tendances</h2>
        <div class="grid">{render_grid(trending_tv, 'tv')}</div>
        """
    return base_layout("home", content, q if q else "")

@app.get("/movies", response_class=HTMLResponse)
def movies_page():
    genres = [
        {"name": "😂 Comédie", "id": 35},
        {"name": "🔥 Action", "id": 28},
        {"name": "🎭 Drame", "id": 18},
        {"name": "🛸 Science-Fiction", "id": 878},
        {"name": "😱 Horreur", "id": 27},
        {"name": "⚡ Animation", "id": 16},
        {"name": "🔎 Thriller", "id": 53},
        {"name": "🗺️ Aventure", "id": 12}
    ]
    
    drawers_html = ""
    for genre in genres:
        data = fetch_tmdb(f"https://api.themoviedb.org/3/discover/movie?api_key={TMDB_API_KEY}&language=fr-FR&with_genres={genre['id']}&sort_by=popularity.desc")
        results = data.get("results", [])
        if results:
            first_poster = results[0].get("poster_path")
            poster_url = f"https://image.tmdb.org/t/p/w500{first_poster}" if first_poster else ""
            
            drawers_html += f"""
            <details class="drawer">
                <summary class="drawer-summary">
                    <img src="{poster_url}" alt="{genre['name']}" class="drawer-poster">
                    <div class="drawer-info">
                        <h3>{genre['name']}</h3>
                        <p>Films populaires — Cliquez pour ouvrir le tiroir 📂</p>
                    </div>
                </summary>
                <div class="drawer-content">
                    <div class="grid">{render_grid(results, 'movie')}</div>
                </div>
            </details>
            """

    content = f"""
    <h2>📂 Catégories de Films</h2>
    <div style="margin-top: 20px;">
        {drawers_html}
    </div>
    """
    return base_layout("movies", content)

@app.get("/series", response_class=HTMLResponse)
def series_page():
    genres = [
        {"name": "😂 Comédie", "id": 35},
        {"name": "🔥 Action & Adventure", "id": 10759},
        {"name": "🎭 Drame", "id": 18},
        {"name": "🛸 Sci-Fi & Fantasy", "id": 10765},
        {"name": "🔎 Mystère", "id": 9648},
        {"name": "⚡ Animation", "id": 16},
        {"name": "🔪 Crime", "id": 80}
    ]
    
    drawers_html = ""
    for genre in genres:
        data = fetch_tmdb(f"https://api.themoviedb.org/3/discover/tv?api_key={TMDB_API_KEY}&language=fr-FR&with_genres={genre['id']}&sort_by=popularity.desc")
        results = data.get("results", [])
        if results:
            first_poster = results[0].get("poster_path")
            poster_url = f"https://image.tmdb.org/t/p/w500{first_poster}" if first_poster else ""
            
            drawers_html += f"""
            <details class="drawer">
                <summary class="drawer-summary">
                    <img src="{poster_url}" alt="{genre['name']}" class="drawer-poster">
                    <div class="drawer-info">
                        <h3>{genre['name']}</h3>
                        <p>Séries populaires — Cliquez pour ouvrir le tiroir 📂</p>
                    </div>
                </summary>
                <div class="drawer-content">
                    <div class="grid">{render_grid(results, 'tv')}</div>
                </div>
            </details>
            """

    content = f"""
    <h2>📂 Catégories de Séries</h2>
    <div style="margin-top: 20px;">
        {drawers_html}
    </div>
    """
    return base_layout("series", content)

@app.get("/sagas", response_class=HTMLResponse)
def sagas_page():
    saga_ids = [
        {"id": 1241}, {"id": 86311}, {"id": 10}, {"id": 9485}, {"id": 119},
        {"id": 263}, {"id": 556}, {"id": 295}, {"id": 328}, {"id": 562},
        {"id": 404609}, {"id": 234}, {"id": 84}, {"id": 8650}, {"id": 748},
        {"id": 645}, {"id": 10194}, {"id": 2150}, {"id": 8091}, {"id": 412497},
        {"id": 131635}, {"id": 335}, {"id": 264}, {"id": 1575}, {"id": 8945}, {"id": 268}
    ]
    
    drawers_html = ""
    for saga in saga_ids:
        data = fetch_tmdb(f"https://api.themoviedb.org/3/collection/{saga['id']}?api_key={TMDB_API_KEY}&language=fr-FR")
        name = data.get("name")
        poster_path = data.get("poster_path")
        parts = data.get("parts", [])
        
        if name and poster_path and parts:
            parts = sorted(parts, key=lambda x: x.get('release_date', '9999'))
            poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}"
            
            drawers_html += f"""
            <details class="drawer">
                <summary class="drawer-summary">
                    <img src="{poster_url}" alt="{name}" class="drawer-poster">
                    <div class="drawer-info">
                        <h3>{name}</h3>
                        <p>{len(parts)} films disponibles — Cliquez pour ouvrir le tiroir 📂</p>
                    </div>
                </summary>
                <div class="drawer-content">
                    <div class="grid">{render_grid(parts, 'movie')}</div>
                </div>
            </details>
            """
            
    content = f"""
    <h2>🗄️ Tiroirs des Sagas Cinématographiques</h2>
    <div style="margin-top: 20px;">
        {drawers_html}
    </div>
    """
    return base_layout("sagas", content)

@app.get("/watch", response_class=HTMLResponse)
def watch(id: int, type: str = "movie", season: int = 1, episode: int = 1):
    """Page de détail et de lecture (Films & Séries avec saisons/épisodes)"""
    url = f"https://api.themoviedb.org/3/{type}/{id}?api_key={TMDB_API_KEY}&language=fr-FR"
    item = fetch_tmdb(url)
    
    title = item.get("title") or item.get("name", "Titre")
    overview = item.get("overview", "Aucun synopsis disponible.")
    vote = round(item.get("vote_average", 0), 1)
    release = item.get("release_date") or item.get("first_air_date", "Inconnue")
    backdrop = item.get("backdrop_path")
    backdrop_url = f"https://image.tmdb.org/t/p/original{backdrop}" if backdrop else ""

    selectors_html = ""
    embed_url = ""

    if type == "tv":
        embed_url = f"https://vidzy.org/tv/{id}/{season}/{episode}"
        
        seasons = item.get("seasons", [])
        seasons_options = ""
        for s in seasons:
            s_num = s.get("season_number")
            if s_num >= 0:
                s_name = s.get("name", f"Saison {s_num}")
                selected = "selected" if s_num == season else ""
                seasons_options += f'<option value="{s_num}" {selected}>{s_name}</option>'
        
        season_data = fetch_tmdb(f"https://api.themoviedb.org/3/tv/{id}/season/{season}?api_key={TMDB_API_KEY}&language=fr-FR")
        episodes = season_data.get("episodes", [])
        episodes_options = ""
        for ep in episodes:
            ep_num = ep.get("episode_number")
            ep_name = ep.get("name", f"Épisode {ep_num}")
            selected = "selected" if ep_num == episode else ""
            episodes_options += f'<option value="{ep_num}" {selected}>Ép. {ep_num} - {ep_name}</option>'
        
        next_episode = episode + 1
        selectors_html = f"""
        <div style="background: rgba(16,16,20,0.9); padding: 15px 20px; border-radius: 10px; margin-bottom: 25px; display: inline-block; border: 1px solid rgba(255,255,255,0.1);">
            <form method="get" action="/watch" style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                <input type="hidden" name="id" value="{id}">
                <input type="hidden" name="type" value="tv">
                <div>
                    <label style="color: var(--text-muted); margin-right: 5px; font-weight: 500;">Saison :</label>
                    <select name="season" onchange="this.form.submit()" style="padding: 8px 12px; background: #222; color: white; border: 1px solid #555; border-radius: 6px; outline: none; cursor: pointer;">
                        {seasons_options}
                    </select>
                </div>
                <div>
                    <label style="color: var(--text-muted); margin-right: 5px; font-weight: 500;">Épisode :</label>
                    <select name="episode" onchange="this.form.submit()" style="padding: 8px 12px; background: #222; color: white; border: 1px solid #555; border-radius: 6px; outline: none; cursor: pointer;">
                        {episodes_options}
                    </select>
                </div>
                <a href="/watch?id={id}&type=tv&season={season}&episode={next_episode}" style="padding: 8px 18px; background: var(--primary); color: white; border-radius: 6px; text-decoration: none; font-weight: bold; transition: background 0.2s; display: inline-block;">▶ Épisode suivant</a>
            </form>
        </div>
        """
    else:
        embed_url = f"https://vidzy.org/movie/{id}"
        selectors_html = ""

    return f"""
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cinéflix - {title}</title>
        <style>
            :root {{
                --bg-color: #0b0b0e;
                --primary: #e50914;
                --primary-hover: #b20710;
            }}
            body {{ background-color: var(--bg-color); color: white; font-family: 'Segoe UI', system-ui, sans-serif; margin: 0; padding: 0; }}
            .hero {{ position: relative; height: 75vh; background: url('{backdrop_url}') no-repeat center center/cover; display: flex; align-items: flex-end; }}
            .hero::after {{ content: ''; position: absolute; inset: 0; background: linear-gradient(to top, var(--bg-color) 10%, rgba(11,11,14,0.7) 50%, rgba(11,11,14,0.3) 100%); }}
            .hero-content {{ position: relative; z-index: 2; padding: 50px; max-width: 950px; }}
            h1 {{ font-size: 3.5rem; margin: 0 0 15px 0; color: #fff; text-shadow: 2px 2px 6px rgba(0,0,0,0.9); }}
            .meta {{ font-size: 1.1rem; color: #4ade80; font-weight: bold; margin-bottom: 20px; display: flex; gap: 25px; align-items: center; text-shadow: 1px 1px 3px rgba(0,0,0,0.8); }}
            .meta span {{ background: rgba(0,0,0,0.6); padding: 5px 10px; border-radius: 6px; }}
            .overview {{ font-size: 1.1rem; color: #cbd5e1; line-height: 1.6; margin-bottom: 25px; max-width: 750px; text-shadow: 1px 1px 3px rgba(0,0,0,0.8); }}
            .btn-watch {{ padding: 14px 35px; background-color: var(--primary); color: white; border: none; border-radius: 8px; font-size: 1.2rem; font-weight: bold; cursor: pointer; text-decoration: none; display: inline-block; transition: background 0.2s, transform 0.2s; box-shadow: 0 4px 15px rgba(229,9,20,0.4); margin-bottom: 15px; }}
            .btn-watch:hover {{ background-color: var(--primary-hover); transform: scale(1.05); }}
            .back-btn {{ position: absolute; top: 25px; left: 40px; z-index: 10; padding: 10px 20px; background: rgba(0,0,0,0.7); backdrop-filter: blur(5px); color: white; text-decoration: none; border-radius: 8px; font-weight: 500; transition: background 0.2s; }}
            .back-btn:hover {{ background: rgba(255,255,255,0.2); }}
            
            .player-section {{ max-width: 1100px; margin: -50px auto 50px auto; padding: 0 20px; position: relative; z-index: 3; text-align: center; }}
            .player-container {{ position: relative; width: 100%; aspect-ratio: 16/9; background: #000; border-radius: 12px; overflow: hidden; box-shadow: 0 15px 40px rgba(0,0,0,0.9); display: none; border: 1px solid rgba(255,255,255,0.1); }}
            iframe {{ width: 100%; height: 100%; border: none; }}
        </style>
    </head>
    <body>
        <a href="/" class="back-btn">⬅ Retour</a>
        
        <div class="hero">
            <div class="hero-content">
                <h1>{title}</h1>
                <div class="meta">
                    <span>⭐ TMDB : {vote} / 10</span>
                    <span>📅 Sortie : {release}</span>
                </div>
                <p class="overview">{overview}</p>
                {selectors_html}
                <br>
                <button class="btn-watch" onclick="loadPlayer()">▶ Lancer la lecture</button>
            </div>
        </div>

        <div class="player-section">
            <div class="player-container" id="playerBox">
                <iframe id="videoFrame" src="" allow="autoplay; fullscreen; encrypted-media" allowfullscreen></iframe>
            </div>
        </div>

        <script>
            function loadParser() {{}}
            function loadPlayer() {{
                const box = document.getElementById('playerBox');
                const frame = document.getElementById('videoFrame');
                frame.src = "{embed_url}";
                box.style.display = 'block';
                box.scrollIntoView({{ behavior: 'smooth' }});
            }}
        </script>
    </body>
    </html>
    """

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)